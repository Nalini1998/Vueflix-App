# VueFlix - Vue Streaming App

A Pen created on CodePen.io. Original URL: [https://codepen.io/Nalini1998/pen/KKbdKWG/252851c47e2ce6cbbfc1a0d98be518c1](https://codepen.io/Nalini1998/pen/KKbdKWG/252851c47e2ce6cbbfc1a0d98be518c1).

A single page online-streaming app built with Vue/Bulma.